package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.VoltageSensor;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.drive.MecanumDrive;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.acmerobotics.roadrunner.trajectory.TrajectoryBuilder;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.util.ElapsedTime;

@Autonomous(name = "specimen")
public class specimen extends LinearOpMode {

    private DcMotor fr;
    private DcMotor fl;
    private DcMotor br;
    private DcMotor bl;
    private DcMotor arm;
    private DcMotor slide;
    private CRServo claw;
    private VoltageSensor batteryVoltageSensor;

    private static final double MAX_VOLTAGE = 12.0;

    // Initialize RoadRunner Drive System
    private RoadRunnerMecanumDrive drive;

    @Override
    public void runOpMode() throws InterruptedException {
        // Initialize motors and hardware
        fr = hardwareMap.get(DcMotor.class, "fr");
        fl = hardwareMap.get(DcMotor.class, "fl");
        br = hardwareMap.get(DcMotor.class, "br");
        bl = hardwareMap.get(DcMotor.class, "bl");
        arm = hardwareMap.get(DcMotor.class, "arm");
        slide = hardwareMap.get(DcMotor.class, "slide");
        claw = hardwareMap.get(CRServo.class, "claw");

        batteryVoltageSensor = hardwareMap.voltageSensor.iterator().next();

        // Initialize RoadRunner drive with encoder feedback
        drive = new RoadRunnerMecanumDrive(hardwareMap);

        // Set motor behaviors
        arm.setTargetPosition(0);
        slide.setTargetPosition(0);
        arm.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        slide.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        // Wait for start
        waitForStart();

        if (opModeIsActive()) {
            // Example autonomous sequence using RoadRunner trajectories

            // Define a trajectory to move forward
            Trajectory forward = drive.trajectoryBuilder(new Pose2d())
                    .forward(48)  // Move forward 48 inches
                    .build();
            drive.followTrajectory(forward);

            // Non-blocking control of claw
            /*ElapsedTime clawTimer = new ElapsedTime();
            claw.setPower(compensatePower(1));  // Activate claw
            while (clawTimer.seconds() < 1.5) {
                // Keep claw running
            }
            claw.setPower(0);  // Stop claw

            // Define trajectory to turn
            Trajectory turn = drive.trajectoryBuilder(forward.end())
                    .turn(Math.toRadians(90))  // Turn right by 90 degrees
                    .build();
            drive.followTrajectory(turn);

            // Move forward again after the turn
            Trajectory forwardAgain = drive.trajectoryBuilder(turn.end())
                    .forward(24)  // Move forward 24 inches
                    .build();
            drive.followTrajectory(forwardAgain);

            // Example of moving backward
            Trajectory back = drive.trajectoryBuilder(forwardAgain.end())
                    .back(24)  // Move backward 24 inches
                    .build();
            drive.followTrajectory(back);

            // Arm movement example with voltage compensation
            arm.setPower(compensatePower(0.5)); // Raise arm
            sleep(1000); // Sleep for 1 second
            arm.setPower(0); // Stop arm

            // Define a trajectory to strafe right
            Trajectory strafeRight = drive.trajectoryBuilder(back.end())
                    .strafeRight(24)  // Strafe right 24 inches
                    .build();
            drive.followTrajectory(strafeRight);

            // Define a trajectory to strafe left
            Trajectory strafeLeft = drive.trajectoryBuilder(strafeRight.end())
                    .strafeLeft(24)  // Strafe left 24 inches
                    .build();
            drive.followTrajectory(strafeLeft);

            // Example of turning left
            Trajectory turnLeft = drive.trajectoryBuilder(strafeLeft.end())
                    .turn(Math.toRadians(-90))  // Turn left by 90 degrees
                    .build();
            drive.followTrajectory(turnLeft);*/

            // Stop all movement
            drive.setDrivePower(new Pose2d(0, 0, 0));
        }
    }

    // Method to get voltage compensation factor
    private double getVoltageCompensationFactor() {
        double voltage = batteryVoltageSensor.getVoltage();
        return voltage > 0 ? MAX_VOLTAGE / voltage : 1;
    }

    // Method to compensate motor power based on battery voltage
    private double compensatePower(double power) {
        return power * getVoltageCompensationFactor();
    }
}

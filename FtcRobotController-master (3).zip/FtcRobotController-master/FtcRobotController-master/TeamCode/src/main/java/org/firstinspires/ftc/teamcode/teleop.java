package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;

import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;

@TeleOp(name = "Teleop")
public class teleop extends LinearOpMode {

//jai sri ram

    public DcMotor  FrontRight;
    public DcMotor  FrontLeft;
    public DcMotor  BackRight;
    public DcMotor  BackLeft;
    public DcMotor  Arm;
    public DcMotor  LSlides;
    public CRServo  Claw;
    public DcMotor  FallCheck;

    final double ARM_TICKS_PER_DEGREE = 19.7924893140647;
    final double ARM_COLLECT               = 250 * ARM_TICKS_PER_DEGREE;
    final double ARM_CLEAR_BARRIER         = 230 * ARM_TICKS_PER_DEGREE;
    final double ARM_SCORE_SPECIMEN        = 160 * ARM_TICKS_PER_DEGREE;
    final double ARM_SCORE_SAMPLE_IN_LOW   = 160 * ARM_TICKS_PER_DEGREE;
    final double ARM_ATTACH_HANGING_HOOK   = 120 * ARM_TICKS_PER_DEGREE;
    final double ARM_WINCH_ROBOT           = -90  * ARM_TICKS_PER_DEGREE;

    final double CLAW_COLLECT    = -1.0;
    final double ClAW_DEPOSIT    =  0.5;

    final double FUDGE_FACTOR = 15 * ARM_TICKS_PER_DEGREE;

    private double armPosition = (int)0;
    double armPositionFudgeFactor;


    @Override
    public void runOpMode() {

        FrontRight  = hardwareMap.get(DcMotor.class, "fr");
        FrontLeft = hardwareMap.get(DcMotor.class, "fl");
        BackRight = hardwareMap.get(DcMotor.class, "br");
        BackLeft = hardwareMap.get(DcMotor.class, "bl");
        Arm = hardwareMap.get(DcMotor.class, "arm");
        LSlides = hardwareMap.get(DcMotor.class, "slide");
        FallCheck = hardwareMap.get(DcMotor.class, "fall");


        FrontRight.setDirection(DcMotor.Direction.REVERSE);
        FrontLeft.setDirection(DcMotor.Direction.FORWARD);
        BackLeft.setDirection(DcMotor.Direction.FORWARD);
        BackRight.setDirection(DcMotor.Direction.REVERSE);

        Arm.setDirection(DcMotor.Direction.REVERSE);
        LSlides.setDirection(DcMotor.Direction.REVERSE);
        FallCheck.setDirection(DcMotor.Direction.REVERSE);

        FrontLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        FrontRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        BackRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        BackLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        Arm.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        LSlides.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        FallCheck.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        Claw = hardwareMap.get(CRServo.class, "Claw");

        Claw.setPower(0);

//-------------------------------------------------------------------------//

        telemetry.addLine("Ready when you are, Captain");
        telemetry.update();
        waitForStart();

        while (opModeIsActive()) {

/***** Gamepad 1 ****/

            //Movement (fw and bw)//

            BackRight.setPower(-gamepad1.left_stick_y);
            telemetry.addData("Left Pow", BackRight.getPower());
            telemetry.addData("Right Pow", BackRight.getPower());
            telemetry.update();

            BackLeft.setPower(-gamepad1.left_stick_y);
            telemetry.addData("Left Pow", BackLeft.getPower());
            telemetry.addData("Right Pow", BackLeft.getPower());
            telemetry.update();

            FrontRight.setPower(-gamepad1.left_stick_y);
            telemetry.addData("Left Pow", FrontRight.getPower());
            telemetry.addData("Right Pow", FrontRight.getPower());
            telemetry.update();

            FrontLeft.setPower(-gamepad1.left_stick_y);
            telemetry.addData("Left Pow", FrontLeft.getPower());
            telemetry.addData("Right Pow", FrontLeft.getPower());
            telemetry.update();

            //Turns

            double y = -gamepad1.left_stick_y; // Remember, Y stick is reversed!
            double rx = gamepad1.right_stick_x;
            BackLeft.setPower(y + rx);
            BackRight.setPower(y - rx);
            FrontLeft.setPower(y + rx);
            FrontRight.setPower(y - rx);

            //Strafe
            /*if(gamepad1.left_stick_x < 0) {
                fr.setDirection(DcMotor.Direction.FORWARD);
                fl.setDirection(DcMotor.Direction.FORWARD);
                bl.setDirection(DcMotor.Direction.REVERSE);
                br.setDirection(DcMotor.Direction.REVERSE);

                br.setPower(-gamepad1.left_stick_x);
                telemetry.addData("Left Pow", br.getPower());
                telemetry.addData("Right Pow", br.getPower());
                telemetry.update();
                bl.setPower(-gamepad1.left_stick_x);
                telemetry.addData("Left Pow", bl.getPower());
                telemetry.addData("Right Pow", bl.getPower());
                telemetry.update();
                fr.setPower(-gamepad1.left_stick_x);
                telemetry.addData("Left Pow", fr.getPower());
                telemetry.addData("Right Pow", fr.getPower());
                telemetry.update();
                fl.setPower(-gamepad1.left_stick_x);
                telemetry.addData("Left Pow", fl.getPower());
                telemetry.addData("Right Pow", fl.getPower());
                telemetry.update();
            }

            if(gamepad1.left_stick_x < 0) {
                fr.setDirection(DcMotor.Direction.FORWARD);
                fl.setDirection(DcMotor.Direction.FORWARD);
                bl.setDirection(DcMotor.Direction.REVERSE);
                br.setDirection(DcMotor.Direction.REVERSE);

                br.setPower(-gamepad1.left_stick_x);
                telemetry.addData("Left Pow", br.getPower());
                telemetry.addData("Right Pow", br.getPower());
                telemetry.update();
                bl.setPower(-gamepad1.left_stick_x);
                telemetry.addData("Left Pow", bl.getPower());
                telemetry.addData("Right Pow", bl.getPower());
                telemetry.update();
                fr.setPower(-gamepad1.left_stick_x);
                telemetry.addData("Left Pow", fr.getPower());
                telemetry.addData("Right Pow", fr.getPower());
                telemetry.update();
                fl.setPower(-gamepad1.left_stick_x);
                telemetry.addData("Left Pow", fl.getPower());
                telemetry.addData("Right Pow", fl.getPower());
                telemetry.update();*/
            }

            //fall
            FallCheck.setPower(gamepad1.right_trigger);
            FallCheck.setPower(-gamepad1.left_trigger);


/***** Gamepad 2 ****/

            //claw
            if (gamepad2.a) {
                Claw.setPower(CLAW_COLLECT);
            }
            if (gamepad2.x) {
                Claw.setPower(0);
            }
            if (gamepad2.b) {
                Claw.setPower(CLAW_DEPOSIT);
            }

            //arm
            Arm.setPower(gamepad2.left_stick_y);


            //slides
            LSlides.setPower(gamepad2.right_stick_y);

//jai sri ram

            telemetry.update();

        }
    }
}
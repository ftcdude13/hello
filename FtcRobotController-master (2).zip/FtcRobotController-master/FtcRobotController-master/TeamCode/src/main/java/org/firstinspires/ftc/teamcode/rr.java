package org.firstinspires.ftc.teamcode;

import com.acmerobotics.roadrunner.drive.MecanumDrive;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

public class RoadRunnerMecanumDrive extends MecanumDrive {

    // Motors
    private DcMotor leftFront, leftRear, rightFront, rightRear;
    private Servo clawServo;

    // Odometry-related fields
    private OdometryWheel leftFrontWheel, leftRearWheel, rightFrontWheel, rightRearWheel;
    private Pose2d poseEstimate;

    public RoadRunnerMecanumDrive(HardwareMap hardwareMap) {
        super(hardwareMap);

        // Initialize motors
        leftFront = hardwareMap.get(DcMotor.class, "leftFront");
        leftRear = hardwareMap.get(DcMotor.class, "leftRear");
        rightFront = hardwareMap.get(DcMotor.class, "rightFront");
        rightRear = hardwareMap.get(DcMotor.class, "rightRear");

        // Set motors to use encoders for odometry
        leftFront.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftRear.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightFront.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightRear.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        // Initialize claw servo (optional)
        clawServo = hardwareMap.get(Servo.class, "claw");

        // Initialize odometry wheels for all four Mecanum wheels
        leftFrontWheel = new OdometryWheel(leftFront, 1); // Example scaling factor
        leftRearWheel = new OdometryWheel(leftRear, 1); // Example scaling factor
        rightFrontWheel = new OdometryWheel(rightFront, 1); // Example scaling factor
        rightRearWheel = new OdometryWheel(rightRear, 1); // Example scaling factor

        // Initialize pose estimate to (0, 0, 0)
        poseEstimate = new Pose2d(0, 0, 0);
    }

    @Override
    public Pose2d getPoseEstimate() {
        // Calculate and return the current pose estimate from odometry
        double x = (leftFrontWheel.getDisplacement() + rightFrontWheel.getDisplacement()
                + leftRearWheel.getDisplacement() + rightRearWheel.getDisplacement()) / 4;
        double y = (leftFrontWheel.getDisplacement() - rightFrontWheel.getDisplacement()
                + leftRearWheel.getDisplacement() - rightRearWheel.getDisplacement()) / 4;
        double heading = (rightFrontWheel.getDisplacement() - leftFrontWheel.getDisplacement()
                + rightRearWheel.getDisplacement() - leftRearWheel.getDisplacement()) / 4;

        poseEstimate = new Pose2d(x, y, heading);
        return poseEstimate;
    }

    @Override
    public void setDrivePower(Pose2d drivePower) {
        // Set motor power based on the desired movement
        leftFront.setPower(drivePower.getX() + drivePower.getY() + drivePower.getHeading());
        leftRear.setPower(drivePower.getX() - drivePower.getY() + drivePower.getHeading());
        rightFront.setPower(drivePower.getX() - drivePower.getY() - drivePower.getHeading());
        rightRear.setPower(drivePower.getX() + drivePower.getY() - drivePower.getHeading());
    }

    public void followTrajectoryExample() {
        // Define a simple trajectory (e.g., move forward and turn)
        Trajectory traj = trajectoryBuilder(new Pose2d())
                .forward(30) // Move forward 30 inches
                .turn(Math.toRadians(90)) // Turn 90 degrees
                .forward(20) // Move forward 20 inches
                .build();

        // Follow the trajectory
        followTrajectory(traj);
    }

    // Example method to open and close a claw
    public void controlClaw(boolean open) {
        if (open) {
            clawServo.setPosition(1.0); // Open claw (adjust as necessary)
        } else {
            clawServo.setPosition(0.0); // Close claw (adjust as necessary)
        }
    }

    // Method to manually drive the robot
    public void manualDrive(double forward, double strafe, double turn) {
        Pose2d manualPower = new Pose2d(forward, strafe, turn);
        setDrivePower(manualPower);
    }

    // Update the odometry (this should be called periodically, e.g., in a loop)
    public void updateOdometry() {
        // Update the pose estimate based on the encoder values from the Mecanum wheels
        double x = (leftFrontWheel.getDisplacement() + rightFrontWheel.getDisplacement()
                + leftRearWheel.getDisplacement() + rightRearWheel.getDisplacement()) / 4;
        double y = (leftFrontWheel.getDisplacement() - rightFrontWheel.getDisplacement()
                + leftRearWheel.getDisplacement() - rightRearWheel.getDisplacement()) / 4;
        double heading = (rightFrontWheel.getDisplacement() - leftFrontWheel.getDisplacement()
                + rightRearWheel.getDisplacement() - leftRearWheel.getDisplacement()) / 4;

        poseEstimate = new Pose2d(x, y, heading); // Update pose estimate
    }
}

package org.firstinspires.ftc.teamcode.tuning;

import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.teamcode.MecanumDrive;

public final class ManualFeedbackTuner extends LinearOpMode {
    public static double DISTANCE = 64; // Distance to drive forward in inches

    @Override
    public void runOpMode() throws InterruptedException {
        // Initialize MecanumDrive
        MecanumDrive drive = new MecanumDrive(hardwareMap, new Pose2d(0, 0, 0));

        // Wait for the start of the OpMode
        waitForStart();

        while (opModeIsActive()) {
            // Drive forward and back by a specified distance
            Actions.runBlocking(
                    drive.actionBuilder(new Pose2d(0, 0, 0))
                            .lineToX(DISTANCE)
                            .lineToX(0)
                            .build());

            // Retrieve encoder values for all four motors (fl, fr, bl, br)
            double frontLeftTicks = drive.fl.getCurrentPosition();
            double frontRightTicks = drive.fr.getCurrentPosition();
            double backLeftTicks = drive.bl.getCurrentPosition();
            double backRightTicks = drive.br.getCurrentPosition();

            // Display encoder tick values for each wheel in telemetry
            telemetry.addData("Front Left Ticks", frontLeftTicks);
            telemetry.addData("Front Right Ticks", frontRightTicks);
            telemetry.addData("Back Left Ticks", backLeftTicks);
            telemetry.addData("Back Right Ticks", backRightTicks);

            // Update telemetry for real-time feedback
            telemetry.update();
        }
    }
}

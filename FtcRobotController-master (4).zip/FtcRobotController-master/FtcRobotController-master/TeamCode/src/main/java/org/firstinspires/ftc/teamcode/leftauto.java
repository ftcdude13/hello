package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.VoltageSensor;
import com.qualcomm.robotcore.hardware.Servo;
import org.firstinspires.ftc.teamcode.drive.MecanumDrive;

@Autonomous(name = "netzoneRR")
public class netzoneRR extends LinearOpMode {

    private MecanumDrive drive;
    private DcMotor arm;
    private DcMotor slide;
    private CRServo claw;
    private VoltageSensor batteryVoltageSensor;

    private static final double MAX_VOLTAGE = 13.0;

    @Override
    public void runOpMode() throws InterruptedException {
        drive = new MecanumDrive(hardwareMap);
        arm = hardwareMap.get(DcMotor.class, "arm");
        slide = hardwareMap.get(DcMotor.class, "slide");
        claw = hardwareMap.get(CRServo.class, "claw");
        batteryVoltageSensor = hardwareMap.voltageSensor.iterator().next();

        arm.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        slide.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        waitForStart();

        if (opModeIsActive()) {
            // Move forward, strafe, turn using RoadRunner
            driveForward(0.5, 1.5);
            strafeRight(0.5, 1.0);
            turnLeft(0.5, 90); // Degrees
            strafeLeft(0.5, 1.0);
            driveBackward(0.5, 1.5);

            // Claw control
            setClaw(1.0, 1.5);
            setClaw(-1.0, 1.5);

            // Arm control
            armUp(0.5, 1.0);
            armDown(0.5, 1.0);

            stopDriving();
        }
    }

    // RoadRunner Drive Methods (Smoother Movements)
    private void driveForward(double power, double time) {
        drive.followTrajectory(
                drive.trajectoryBuilder(drive.getPoseEstimate())
                        .forward(power * time)
                        .build()
        );
    }

    private void driveBackward(double power, double time) {
        drive.followTrajectory(
                drive.trajectoryBuilder(drive.getPoseEstimate())
                        .back(power * time)
                        .build()
        );
    }

    private void strafeLeft(double power, double time) {
        drive.followTrajectory(
                drive.trajectoryBuilder(drive.getPoseEstimate())
                        .strafeLeft(power * time)
                        .build()
        );
    }

    private void strafeRight(double power, double time) {
        drive.followTrajectory(
                drive.trajectoryBuilder(drive.getPoseEstimate())
                        .strafeRight(power * time)
                        .build()
        );
    }

    private void turnLeft(double power, double degrees) {
        drive.turn(Math.toRadians(degrees));  // Convert degrees to radians
    }

    private void turnRight(double power, double degrees) {
        drive.turn(-Math.toRadians(degrees));  // Convert degrees to radians
    }

    // Arm control methods
    private void armUp(double power, long time) throws InterruptedException {
        arm.setPower(power);
        Thread.sleep(time);
        arm.setPower(0);
    }

    private void armDown(double power, long time) throws InterruptedException {
        arm.setPower(-power);
        Thread.sleep(time);
        arm.setPower(0);
    }

    // Claw control method
    private void setClaw(double power, long time) throws InterruptedException {
        claw.setPower(power);
        Thread.sleep(time);
        claw.setPower(0);
    }

    // Stop all motors
    private void stopDriving() {
        drive.setMotorPowers(0, 0, 0, 0);
    }
}

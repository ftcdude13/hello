package org.firstinspires.ftc.teamcode;

import com.acmerobotics.roadrunner.drive.MecanumDrive;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.acmerobotics.roadrunner.trajectory.TrajectoryBuilder;
import com.acmerobotics.roadrunner.trajectory.constraints.TrajectoryVelocityConstraint;
import com.acmerobotics.roadrunner.trajectory.constraints.TrajectoryAccelerationConstraint;
import com.acmerobotics.roadrunner.localization.Localizer;
import com.acmerobotics.roadrunner.localization.StandardTrackingWheelLocalizer;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;

public class RoadRunnerMecanumDrive extends MecanumDrive {

    // Motors
    private DcMotor leftFront, leftRear, rightFront, rightRear;

    // Odometry localization
    private StandardTrackingWheelLocalizer localizer;

    // Robot geometry (distance between wheels)
    private double trackWidth = 12.0; // distance between left and right wheels in inches
    private double wheelbase = 16.0; // distance between front and rear wheels in inches

    public RoadRunnerMecanumDrive(HardwareMap hardwareMap) {
        super(hardwareMap);

        // Initialize motors
        leftFront = hardwareMap.get(DcMotor.class, "leftFront");
        leftRear = hardwareMap.get(DcMotor.class, "leftRear");
        rightFront = hardwareMap.get(DcMotor.class, "rightFront");
        rightRear = hardwareMap.get(DcMotor.class, "rightRear");

        // Set motors to use encoders for odometry
        leftFront.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftRear.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightFront.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightRear.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        // Initialize odometry localizer (Road Runner standard localizer)
        localizer = new StandardTrackingWheelLocalizer(hardwareMap);

        // Initialize pose estimate to (0, 0, 0)
        setPoseEstimate(new Pose2d(0, 0, 0));
    }

    @Override
    public Pose2d getPoseEstimate() {
        return localizer.getPoseEstimate();
    }

    @Override
    public void setDrivePower(Pose2d drivePower) {
        // Set motor power based on the desired movement (Mecanum drive kinematics)
        double leftFrontPower = drivePower.getX() + drivePower.getY() + drivePower.getHeading();
        double leftRearPower = drivePower.getX() - drivePower.getY() + drivePower.getHeading();
        double rightFrontPower = drivePower.getX() - drivePower.getY() - drivePower.getHeading();
        double rightRearPower = drivePower.getX() + drivePower.getY() - drivePower.getHeading();

        leftFront.setPower(leftFrontPower);
        leftRear.setPower(leftRearPower);
        rightFront.setPower(rightFrontPower);
        rightRear.setPower(rightRearPower);
    }

    public void followTrajectoryExample() {
        // Define trajectory constraints (velocity and acceleration)
        TrajectoryVelocityConstraint velocityConstraint = new MecanumVelocityConstraint(30); // Example velocity constraint
        TrajectoryAccelerationConstraint accelerationConstraint = new MecanumAccelerationConstraint(20); // Example acceleration constraint

        // Define a simple trajectory (e.g., move forward and turn)
        Trajectory traj = trajectoryBuilder(new Pose2d())
                .forward(30) // Move forward 30 inches
                .turn(Math.toRadians(90)) // Turn 90 degrees
                .forward(20) // Move forward 20 inches
                .build();

        // Follow the trajectory
        followTrajectory(traj);
    }

    // Method to manually drive the robot
    public void manualDrive(double forward, double strafe, double turn) {
        Pose2d manualPower = new Pose2d(forward, strafe, turn);
        setDrivePower(manualPower);
    }

    // Update the odometry (this should be called periodically, e.g., in a loop)
    public void updateOdometry() {
        localizer.update();
    }
}

package org.firstinspires.ftc.teamcode;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.VoltageSensor;

//jai sri ram

@Autonomous(name = "netzone")
public class netzone extends LinearOpMode {

    public static final long BEFORE_TURN_FORWARD_TIME  = 1000;
    public static final long RIGHT_TURN_TIME  = 1500;
    public static final long LEFT_TURN_TIME  = 1000;
    public static final long AFTER_TURN_TIME  = 1000;
    private DcMotor fr;
    private DcMotor fl;
    private DcMotor br;
    private DcMotor bl;
    private DcMotor arm;
    private DcMotor slide;
    private CRServo claw;
    //private Servo wrist;
    private VoltageSensor batteryVoltageSensor;

    private static final double MAX_VOLTAGE = 13.0;

    @Override
    public void runOpMode() throws InterruptedException {
        fr  = hardwareMap.get(DcMotor.class, "fr");
        fl = hardwareMap.get(DcMotor.class, "fl");
        br = hardwareMap.get(DcMotor.class, "br");
        bl = hardwareMap.get(DcMotor.class, "bl");
        arm = hardwareMap.get(DcMotor.class, "arm");
        slide = hardwareMap.get(DcMotor.class, "slide");
        claw = hardwareMap.get(CRServo.class, "claw");
        //wrist = hardwareMap.get(Servo.class, "wrist");
        batteryVoltageSensor = hardwareMap.voltageSensor.iterator().next();

        double DRIVE_POWER = 0.3;
        double lefts;
        double rights;

        arm.setTargetPosition(0);
        slide.setTargetPosition(0);
        arm.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        slide.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        waitForStart();

        if (opModeIsActive()) {
            while (opModeIsActive()) {

                Thread.sleep(1000);
                claw.setPower(1);
                Thread.sleep(1500);
                ArmUppower(.5, 570);
                Thread.sleep(300);
                DriveForward(0.5, 370);
                Thread.sleep(100);
                claw.setPower(1.0);
                Thread.sleep(500);
                ArmUppower(0.5, 1565);
                Thread.sleep(500);
                DriveForward(0.4, 860);
                Thread.sleep(300);
                ArmDownpower(.8, 265); // clip spec1
                Thread.sleep(300);
                ArmUppower(.5, 450);
                Thread.sleep(500);
                claw.setPower(-0.5);
                Thread.sleep(400);

                DriveBackward(0.5, 300);

                StrafeLeft(0.5, 1600);
                Thread.sleep(200);
                TurnLeft(0.1, 100);
                Thread.sleep(100);
                DriveForward(0.6, 1100);
                Thread.sleep(200);
                TurnRight(0.5, 1100);



                Thread.sleep(200);
                StrafeRight(0.5, 500);
                Thread.sleep(200);
                ArmDownpower(0.3,200);
                Thread.sleep(300);

                /* First Block */
                DriveForward(0.5, 2200);
                Thread.sleep(200);
                DriveBackward(0.5, 1900);
                Thread.sleep(200);

                /* Second block */
                StrafeRight(0.5, 495);
                Thread.sleep(200);
                DriveForward(0.5, 2100);
                Thread.sleep(100);
                TurnRight(.2,100);
                Thread.sleep(200);
                DriveBackward(0.5, 1800);
                Thread.sleep(200);
                TurnLeft(0.5, 450);
                Thread.sleep(300);
                DriveBackward(.5,1200);
                Thread.sleep(300);
                ArmUppower(.8,1700);
                Thread.sleep(1000);



               /* Thread.sleep(200);
                StrafeRight(0.5, 440);
                Thread.sleep(200);
                DriveForward(0.5, 2000);*/

                /*Thread.sleep(100);
                DriveBackward(0.5, 1800);
                Thread.sleep(100);
                TurnLeft(.5, 300);
                Thread.sleep(100);
                DriveBackward(.5, 1000);
                Thread.sleep(300);
                ArmUppower(.5,1000);*/


                StopDriving();
            }
        }
    }

    private double getVoltageCompensationFactor() {
        double voltage = batteryVoltageSensor.getVoltage();
        return voltage > 0 ? MAX_VOLTAGE / voltage : 1;
    }

    private double compensatePower(double power) {
        return power * getVoltageCompensationFactor();
    }

    public void StrafeLeft(double power, long time) throws InterruptedException {
        TurnlessLeft(compensatePower(power));
        Thread.sleep(time);
        TurnlessRight(0);
    }

    public void TurnlessLeft(double power) {
        fr.setDirection(DcMotor.Direction.REVERSE);
        fl.setDirection(DcMotor.Direction.REVERSE);
        bl.setDirection(DcMotor.Direction.FORWARD);
        br.setDirection(DcMotor.Direction.FORWARD);

        br.setPower(power);
        bl.setPower(power);
        fr.setPower(power);
        fl.setPower(power);

        fr.setDirection(DcMotor.Direction.FORWARD);
        fl.setDirection(DcMotor.Direction.REVERSE);
        bl.setDirection(DcMotor.Direction.REVERSE);
        br.setDirection(DcMotor.Direction.FORWARD);
    }

    public void TurnlessRight(double power) {
        fr.setDirection(DcMotor.Direction.FORWARD);
        fl.setDirection(DcMotor.Direction.FORWARD);
        bl.setDirection(DcMotor.Direction.REVERSE);
        br.setDirection(DcMotor.Direction.REVERSE);

        br.setPower(power);
        bl.setPower(power);
        fr.setPower(power);
        fl.setPower(power);

        fr.setDirection(DcMotor.Direction.REVERSE);
        fl.setDirection(DcMotor.Direction.FORWARD);
        bl.setDirection(DcMotor.Direction.FORWARD);
        br.setDirection(DcMotor.Direction.REVERSE);
    }

    public void StrafeRight(double power, long time) throws InterruptedException {
        TurnlessRight(compensatePower(power));
        Thread.sleep(time);
        TurnlessLeft(0);
    }

    public void MoveForward(double power) {
        fr.setDirection(DcMotor.Direction.REVERSE);
        fl.setDirection(DcMotor.Direction.FORWARD);
        bl.setDirection(DcMotor.Direction.FORWARD);
        br.setDirection(DcMotor.Direction.REVERSE);
        fr.setPower(compensatePower(power));
        fl.setPower(compensatePower(power));
        br.setPower(compensatePower(power));
        bl.setPower(compensatePower(power));
    }

    public void DriveForward(double power, long time) throws InterruptedException {
        MoveForward(power);
        Thread.sleep(time);
        MoveForward(0);
    }

    public void MoveBackward(double power) {
        fr.setDirection(DcMotor.Direction.FORWARD);
        fl.setDirection(DcMotor.Direction.REVERSE);
        bl.setDirection(DcMotor.Direction.REVERSE);
        br.setDirection(DcMotor.Direction.FORWARD);
        fr.setPower(compensatePower(power));
        fl.setPower(compensatePower(power));
        br.setPower(compensatePower(power));
        bl.setPower(compensatePower(power));
    }

    public void DriveBackward(double power, long time) throws InterruptedException {
        MoveBackward(power);
        Thread.sleep(time);
        MoveBackward(0);
    }

    public void RotateLeft(double power) {
        fr.setDirection(DcMotor.Direction.REVERSE);
        fl.setDirection(DcMotor.Direction.REVERSE);
        bl.setDirection(DcMotor.Direction.REVERSE);
        br.setDirection(DcMotor.Direction.REVERSE);
        fr.setPower(compensatePower(power));
        fl.setPower(compensatePower(power));
        br.setPower(compensatePower(power));
        bl.setPower(compensatePower(power));
    }

    public void TurnRight(double power, long time) throws InterruptedException {
        RotateLeft(power);
        Thread.sleep(time);
    }

    public void RotateRight(double power) {
        fr.setDirection(DcMotor.Direction.FORWARD);
        fl.setDirection(DcMotor.Direction.FORWARD);
        bl.setDirection(DcMotor.Direction.FORWARD);
        br.setDirection(DcMotor.Direction.FORWARD);
        fr.setPower(compensatePower(power));
        fl.setPower(compensatePower(power));
        br.setPower(compensatePower(power));
        bl.setPower(compensatePower(power));
    }

    public void TurnLeft(double power, long time) throws InterruptedException {
        RotateRight(power);
        Thread.sleep(time);
    }

    public void ArmRever(double pos) {
        arm.setDirection(DcMotorSimple.Direction.REVERSE);
        arm.setPower(compensatePower(pos));
    }

    public void ArmUppower(double power, long time) throws InterruptedException {
        arm.setDirection(DcMotorSimple.Direction.FORWARD);
        arm.setPower(compensatePower(power));
        Thread.sleep(time);
        arm.setPower(0);
    }

    public void ArmDownpower(double power, long time) throws InterruptedException {
        arm.setDirection(DcMotorSimple.Direction.REVERSE);
        arm.setPower(compensatePower(power));
        Thread.sleep(time);
        arm.setPower(0);
    }

    public void ArmUp(double pos, long time) throws InterruptedException {
        Thread.sleep(time);
    }

    public void ArmDown(double pos, long time) throws InterruptedException {
        ArmRever(pos);
        Thread.sleep(time);
    }

    public void slidesUp(double pos, long time) throws InterruptedException {
        slidetop(pos);
        Thread.sleep(time);
    }

    public void slidesDown(double pos, long time) throws InterruptedException {
        slidebottom(pos);
        Thread.sleep(time);
    }

    public void slidetop(double pos) {
        slide.setDirection(DcMotorSimple.Direction.FORWARD);
        slide.setPower(compensatePower(pos));
    }

    public void slidebottom(double pos) {
        slide.setDirection(DcMotorSimple.Direction.REVERSE);
        slide.setPower(compensatePower(pos));
    }

    public void claws(double power) {
        claw.setPower(compensatePower(power));
    }

    public void setclaw(double power, long time) throws InterruptedException {
        claws(power);
        Thread.sleep(time);
    }

    public void StopDriving() throws InterruptedException {
        while (opModeIsActive()) {
            MoveForward(0);
            Thread.sleep(10);
        }
    }

    public void StopArm() throws InterruptedException {
        ArmRever(0);
        Thread.sleep(10);
    }
}